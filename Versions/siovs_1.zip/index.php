<?php
declare(strict_types=1);

require __DIR__ . '/config/bootstrap.php';
require_login();
log_activity($pdo, 'page_view', 'dashboard');

/* ── Dashboard KPIs ──────────────────────────────────────────────────────── */
$today = date('Y-m-d');

// Inventory KPIs
$totalItems   = (int) $pdo->query('SELECT COUNT(*) FROM items')->fetchColumn();
$lowStock     = (int) $pdo->query('SELECT COUNT(*) FROM items WHERE quantity <= reorder_level AND quantity > 0')->fetchColumn();
$criticalStock= (int) $pdo->query('SELECT COUNT(*) FROM items WHERE quantity = 0')->fetchColumn();
$expiredItems = (int) $pdo->query("SELECT COUNT(*) FROM items WHERE expiry_date IS NOT NULL AND expiry_date < '{$today}'")->fetchColumn();
$nearExpiry30 = (int) $pdo->query("SELECT COUNT(*) FROM items WHERE expiry_date IS NOT NULL AND expiry_date >= '{$today}' AND expiry_date <= date('{$today}','+30 days')")->fetchColumn();

// Pending items
$pendingGRNs  = (int) $pdo->query('SELECT COUNT(*) FROM grns WHERE inspection_status = "Pending"')->fetchColumn();
$pendingReqs  = (int) $pdo->query('SELECT COUNT(*) FROM requisitions WHERE status IN ("Draft","Approved")')->fetchColumn();
$pendingAdj   = (int) $pdo->query('SELECT COUNT(*) FROM stock_adjustments WHERE status = "Pending"')->fetchColumn();

// Transaction counts
$totalPOs     = (int) $pdo->query('SELECT COUNT(*) FROM purchase_orders')->fetchColumn();
$openPOs      = (int) $pdo->query('SELECT COUNT(*) FROM purchase_orders WHERE status NOT IN ("Delivered","Cancelled")')->fetchColumn();
$totalAssets  = (int) $pdo->query('SELECT COUNT(*) FROM assets')->fetchColumn();
$assetsRepair = (int) $pdo->query('SELECT COUNT(*) FROM assets WHERE status = "Under repair"')->fetchColumn();

// Near-expiry assets (AMC/warranty)
$assetWarrantyExpiring = (int) $pdo->query("SELECT COUNT(*) FROM assets WHERE warranty_until IS NOT NULL AND warranty_until >= '{$today}' AND warranty_until <= date('{$today}','+30 days')")->fetchColumn();

// Today's consumption
$todayOPD = (int) $pdo->query("SELECT COUNT(DISTINCT patient_mr) FROM consumption_records WHERE type='OPD' AND date(created_at)='{$today}'")->fetchColumn();
$todayOT  = (int) $pdo->query("SELECT COUNT(DISTINCT surgery_number) FROM consumption_records WHERE type='OT' AND date(created_at)='{$today}'")->fetchColumn();

// Stock value (estimated from last received rate × quantity)
$stockValue = (float) $pdo->query(
    "SELECT COALESCE(SUM(i.quantity * COALESCE(
        (SELECT g.rate FROM grn_items g WHERE g.item_id=i.id AND g.rate>0 ORDER BY g.id DESC LIMIT 1),
        0
    )),0) FROM items i"
)->fetchColumn();

// Recent transactions
$recentTx = $pdo->query(
    'SELECT * FROM transactions ORDER BY id DESC LIMIT 6'
)->fetchAll(PDO::FETCH_ASSOC);

// Near-expiry items list
$expiryItems = $pdo->query(
    "SELECT name, code, quantity, expiry_date,
            CAST(julianday(expiry_date) - julianday('now') AS INTEGER) as days_left
     FROM items
     WHERE expiry_date IS NOT NULL AND expiry_date >= '{$today}'
     ORDER BY expiry_date ASC LIMIT 5"
)->fetchAll(PDO::FETCH_ASSOC);

// Low-stock items list
$lowStockItems = $pdo->query(
    'SELECT name, code, quantity, reorder_level, status FROM items
     WHERE quantity <= reorder_level ORDER BY quantity ASC LIMIT 5'
)->fetchAll(PDO::FETCH_ASSOC);

// ── Sparkline: last 7 days transaction counts ──────────────────────────────
$sparkRows = $pdo->query(
    "SELECT date(created_at) as day, COUNT(*) as cnt
     FROM transactions
     WHERE created_at >= date('now','-6 days')
     GROUP BY date(created_at)
     ORDER BY day ASC"
)->fetchAll(PDO::FETCH_ASSOC);
$sparkMap = [];
foreach ($sparkRows as $r) { $sparkMap[$r['day']] = (int)$r['cnt']; }
$sparkDays = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-{$i} days"));
    $sparkDays[] = $sparkMap[$d] ?? 0;
}
$sparkJson = json_encode($sparkDays);

// ── Pending-actions list for the alert banner ──────────────────────────────
$pendingActions = [];
if ($pendingGRNs > 0) $pendingActions[] = ['label' => "{$pendingGRNs} GRN" . ($pendingGRNs > 1 ? 's' : '') . ' pending inspection',         'link' => page_link('grn'),          'perm' => 'grn'];
if ($pendingReqs > 0) $pendingActions[] = ['label' => "{$pendingReqs} requisition" . ($pendingReqs > 1 ? 's' : '') . ' awaiting action',     'link' => page_link('requisitions'), 'perm' => 'requisitions'];
if ($pendingAdj  > 0) $pendingActions[] = ['label' => "{$pendingAdj} stock adjustment" . ($pendingAdj > 1 ? 's' : '') . ' pending approval', 'link' => page_link('adjustments'),  'perm' => 'adjustments'];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SIOVS · Command Center</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="assets/system.css">
    <link rel="stylesheet" href="assets/green-theme.css">
</head>
<body>
<?php
$current = 'dashboard';
$title   = 'Dashboard';
$flash   = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
$u        = current_user();
$initials = implode('', array_map(fn($w) => strtoupper($w[0]), array_slice(explode(' ', $u['name'] ?? 'U'), 0, 2)));
$firstName = explode(' ', $u['name'] ?? 'there')[0];
?>
<div class="app-shell">
<aside class="sidebar">
    <a class="brand brand-centered" href="index.php">
        <img class="brand-logo" src="https://siovs.edu.pk/wp-content/uploads/2022/09/logo-main.png" alt="SIOVS logo">
        <span class="brand-title">
            <strong>SIOVS</strong>
            <small>STORE, INVENTORY &amp;<br>ASSET MANAGEMENT<br>SYSTEM</small>
        </span>
    </a>
    <div class="workspace-switcher"><span class="dot"></span><span>SIOVS Hyderabad</span><span class="chevron">⌄</span></div>
    <nav>
        <p class="nav-label">Overview</p>
        <a class="nav-link active" href="index.php"><span>◈</span> Dashboard</a>
        <?php if (can('reports')): ?>
        <a class="nav-link" href="<?= page_link('reports') ?>"><span>▥</span> Reports &amp; analytics</a>
        <?php endif; ?>

        <p class="nav-label">Inventory</p>
        <?php if (can('inventory')): ?><a class="nav-link" href="<?= page_link('inventory') ?>"><span>◫</span> Item master / stock</a><?php endif; ?>
        <?php if (can('batches')): ?><a class="nav-link" href="<?= page_link('batches') ?>"><span>◷</span> Batch &amp; expiry<?php if ($nearExpiry30 > 0): ?> <b class="nav-count"><?= $nearExpiry30 ?></b><?php endif; ?></a><?php endif; ?>
        <?php if (can('adjustments')): ?><a class="nav-link" href="<?= page_link('adjustments') ?>"><span>⇌</span> Stock adjustments<?php if ($pendingAdj > 0): ?> <b class="nav-count"><?= $pendingAdj ?></b><?php endif; ?></a><?php endif; ?>
        <?php if (can('verification')): ?><a class="nav-link" href="<?= page_link('verification') ?>"><span>✓</span> Stock verification</a><?php endif; ?>

        <?php if (can('requisitions')): ?>
        <p class="nav-label">Requisitions &amp; Issues</p>
        <a class="nav-link" href="<?= page_link('requisitions') ?>"><span>⌁</span> Issue requisition<?php if ($pendingReqs > 0): ?> <b class="nav-count"><?= $pendingReqs ?></b><?php endif; ?></a>
        <?php endif; ?>

        <?php if (can('purchase_orders') || can('suppliers') || can('grn')): ?>
        <p class="nav-label">Purchase &amp; Receiving</p>
        <?php if (can('suppliers')): ?><a class="nav-link" href="<?= page_link('suppliers') ?>"><span>⊞</span> Suppliers</a><?php endif; ?>
        <?php if (can('purchase_orders')): ?><a class="nav-link" href="<?= page_link('purchase_orders') ?>"><span>↗</span> Purchase orders<?php if ($openPOs > 0): ?> <b class="nav-count"><?= $openPOs ?></b><?php endif; ?></a><?php endif; ?>
        <?php if (can('grn')): ?><a class="nav-link" href="<?= page_link('grn') ?>"><span>▣</span> Goods received (GRN)<?php if ($pendingGRNs > 0): ?> <b class="nav-count"><?= $pendingGRNs ?></b><?php endif; ?></a><?php endif; ?>
        <?php endif; ?>

        <?php if (can('opd_consumption') || can('ipd_consumption') || can('ot_consumption') || can('emergency')): ?>
        <p class="nav-label">Departments &amp; Issues</p>
        <?php if (can('opd_consumption')): ?><a class="nav-link" href="<?= page_link('opd_consumption') ?>"><span>✚</span> OPD consumption</a><?php endif; ?>
        <?php if (can('ipd_consumption')): ?><a class="nav-link" href="<?= page_link('ipd_consumption') ?>"><span>⊕</span> IPD / Ward</a><?php endif; ?>
        <?php if (can('ot_consumption')): ?><a class="nav-link" href="<?= page_link('ot_consumption') ?>"><span>⊗</span> OT / Surgery</a><?php endif; ?>
        <?php if (can('emergency')): ?><a class="nav-link" href="<?= page_link('emergency') ?>"><span>!</span> Emergency</a><?php endif; ?>
        <?php endif; ?>

        <?php if (can('assets') || can('departments')): ?>
        <p class="nav-label">Assets &amp; Control</p>
        <?php if (can('assets')): ?><a class="nav-link" href="<?= page_link('assets') ?>"><span>▤</span> Fixed assets</a><?php endif; ?>
        <?php if (can('departments')): ?><a class="nav-link" href="<?= page_link('departments') ?>"><span>⊟</span> Departments</a><?php endif; ?>
        <?php if (can('returns')): ?><a class="nav-link" href="<?= page_link('returns') ?>"><span>↻</span> Returns</a><?php endif; ?>
        <?php if (can('users')): ?><a class="nav-link" href="<?= page_link('users') ?>"><span>♙</span> Users &amp; roles</a><?php endif; ?>
        <?php endif; ?>
        <?php if (can('quick-entry')): ?>
        <p class="nav-label">Quick Entry</p>
        <a class="nav-link" href="<?= page_link('quick-entry') ?>"><span>＋</span> Quick entry</a>
        <?php endif; ?>
    </nav>
    <div class="sidebar-bottom">
        <div class="user-chip">
            <span class="avatar"><?= e($initials) ?></span>
            <div><strong><?= e($u['name'] ?? '') ?></strong><small><?= e(role_label($u['role'] ?? '')) ?></small></div>
            <a class="logout" href="logout.php" title="Sign out">↪</a>
        </div>
    </div>
</aside>

<main class="main">
<header class="topbar">
    <div class="breadcrumbs"><span>Workspace</span><b>/</b><strong>Dashboard</strong></div>
    <div class="top-actions">

        <!-- ── Bell alerts button + dropdown ── -->
        <?php $alertCount = $nearExpiry30 + $criticalStock + $pendingAdj + $pendingGRNs; ?>
        <div class="alerts-wrap" id="alerts-wrap">
            <button class="icon-button alerts-btn" id="alerts-btn" title="Alerts" aria-haspopup="true" aria-expanded="false">
                <!-- Bell SVG icon -->
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                    <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
                </svg>
                <?php if ($alertCount > 0): ?>
                <i class="alert-badge"><?= $alertCount ?></i>
                <?php endif; ?>
            </button>

            <!-- Dropdown panel -->
            <div class="alerts-dropdown" id="alerts-dropdown" role="dialog" aria-label="Alerts">
                <div class="alerts-dd-header">
                    <strong>Alerts</strong>
                    <span class="alerts-dd-count"><?= $alertCount ?> active</span>
                </div>
                <ul class="alerts-dd-list">
                    <?php if ($criticalStock > 0): ?>
                    <li class="ad-item ad-red">
                        <span class="ad-dot"></span>
                        <div>
                            <b><?= $criticalStock ?> item<?= $criticalStock > 1 ? 's' : '' ?> out of stock</b>
                            <small>Immediate reorder required</small>
                        </div>
                        <a href="<?= page_link('inventory') ?>" class="ad-action">View →</a>
                    </li>
                    <?php endif; ?>
                    <?php if ($nearExpiry30 > 0): ?>
                    <li class="ad-item ad-amber">
                        <span class="ad-dot"></span>
                        <div>
                            <b><?= $nearExpiry30 ?> item<?= $nearExpiry30 > 1 ? 's' : '' ?> expiring in 30 days</b>
                            <small>Review FEFO allocation</small>
                        </div>
                        <a href="<?= page_link('batches') ?>" class="ad-action">View →</a>
                    </li>
                    <?php endif; ?>
                    <?php if ($pendingAdj > 0): ?>
                    <li class="ad-item ad-amber">
                        <span class="ad-dot"></span>
                        <div>
                            <b><?= $pendingAdj ?> stock adjustment<?= $pendingAdj > 1 ? 's' : '' ?> pending</b>
                            <small>Awaiting approval</small>
                        </div>
                        <a href="<?= page_link('adjustments') ?>" class="ad-action">View →</a>
                    </li>
                    <?php endif; ?>
                    <?php if ($pendingGRNs > 0): ?>
                    <li class="ad-item ad-blue">
                        <span class="ad-dot"></span>
                        <div>
                            <b><?= $pendingGRNs ?> GRN<?= $pendingGRNs > 1 ? 's' : '' ?> pending inspection</b>
                            <small>Goods received, not yet inspected</small>
                        </div>
                        <a href="<?= page_link('grn') ?>" class="ad-action">View →</a>
                    </li>
                    <?php endif; ?>
                    <?php if ($alertCount === 0): ?>
                    <li class="ad-item ad-ok">
                        <span class="ad-dot"></span>
                        <div><b>All clear</b><small>No active alerts right now</small></div>
                    </li>
                    <?php endif; ?>
                </ul>
                <div class="alerts-dd-footer">
                    <a href="<?= page_link('reports') ?>">View full report →</a>
                </div>
            </div>
        </div>

        <!-- ── Spotlight search button ── -->
        <button class="icon-button" id="spotlight-btn" title="Search modules (Ctrl+K)">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
        </button>

        <?php if (can('quick-entry')): ?>
        <a class="button button-primary" href="<?= page_link('quick-entry') ?>">＋ Quick entry</a>
        <?php endif; ?>
    </div>
</header>
<?php if ($flash): ?>
<div class="flash <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>

<?php if (!empty($pendingActions)): ?>
<!-- ── Pending-actions banner ────────────────────────────────────────── -->
<div class="pending-banner" id="pending-banner">
    <span class="pending-icon">⚑</span>
    <div class="pending-items">
        <?php foreach ($pendingActions as $pa): if (!can($pa['perm'])) continue; ?>
        <a href="<?= e($pa['link']) ?>" class="pending-link"><?= e($pa['label']) ?> →</a>
        <?php endforeach; ?>
    </div>
    <button class="pending-dismiss" onclick="this.closest('.pending-banner').style.display='none';sessionStorage.setItem('siovs_banner_dismissed','1')" title="Dismiss">×</button>
</div>
<script>if(sessionStorage.getItem('siovs_banner_dismissed')==='1'){var b=document.getElementById('pending-banner');if(b)b.style.display='none';}</script>
<?php endif; ?>

<section class="page-content" id="dashboard">

    <!-- ── Hero banner ───────────────────────────────────────────────── -->
    <div class="hero">
        <div>
            <p class="eyebrow" id="hero-date"><?= strtoupper(date('l, j F Y')) ?></p>
            <h1 class="hero-greeting" id="hero-greeting">Good day, <?= e($firstName) ?></h1>
            <p class="hero-copy">Your complete view from purchase to patient. <span id="live-clock" style="font-weight:600;color:#e8f37c"></span></p>
        </div>
        <div class="hero-decoration"><span></span><span></span><span></span></div>
    </div>

    <!-- ── KPI Row 1: Inventory ──────────────────────────────────────── -->
    <div class="section-heading">
        <div><p class="eyebrow">LIVE SNAPSHOT</p><h2>Inventory at a glance</h2></div>
        <button class="button button-light" id="refresh-kpi" title="Refresh KPIs" style="font-size:11px;padding:7px 13px">↻ Refresh</button>
    </div>
    <div class="metric-grid" id="kpi-row-1">

        <!-- Card 1: Inventory / Stock units -->
        <article class="metric-card kpi-card kpi-inventory" data-link="<?= page_link('inventory') ?>" data-spark='<?= $sparkJson ?>' style="--delay:0">
            <div class="kpi-illustration" aria-hidden="true">
                <!-- Warehouse shelves with boxes -->
                <svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <!-- Shelves -->
                    <rect x="10" y="95" width="140" height="5" rx="2" fill="white" opacity=".25"/>
                    <rect x="10" y="60" width="140" height="5" rx="2" fill="white" opacity=".25"/>
                    <rect x="10" y="25" width="140" height="5" rx="2" fill="white" opacity=".25"/>
                    <!-- Vertical supports -->
                    <rect x="10" y="25" width="5" height="75" rx="2" fill="white" opacity=".18"/>
                    <rect x="145" y="25" width="5" height="75" rx="2" fill="white" opacity=".18"/>
                    <!-- Bottom row boxes -->
                    <rect x="18" y="72" width="28" height="23" rx="3" fill="white" opacity=".35"/>
                    <rect x="20" y="74" width="24" height="5" rx="1" fill="white" opacity=".3"/>
                    <rect x="50" y="72" width="28" height="23" rx="3" fill="white" opacity=".28"/>
                    <rect x="82" y="72" width="28" height="23" rx="3" fill="white" opacity=".35"/>
                    <rect x="114" y="72" width="28" height="23" rx="3" fill="white" opacity=".28"/>
                    <!-- Middle row boxes -->
                    <rect x="18" y="37" width="22" height="22" rx="3" fill="white" opacity=".28"/>
                    <rect x="44" y="37" width="22" height="22" rx="3" fill="white" opacity=".35"/>
                    <rect x="44" y="39" width="22" height="5" rx="1" fill="white" opacity=".3"/>
                    <rect x="70" y="37" width="22" height="22" rx="3" fill="white" opacity=".22"/>
                    <rect x="96" y="37" width="22" height="22" rx="3" fill="white" opacity=".35"/>
                    <rect x="122" y="37" width="22" height="22" rx="3" fill="white" opacity=".28"/>
                    <!-- Top row -->
                    <rect x="18" y="10" width="18" height="14" rx="3" fill="white" opacity=".22"/>
                    <rect x="40" y="10" width="18" height="14" rx="3" fill="white" opacity=".3"/>
                    <rect x="62" y="10" width="18" height="14" rx="3" fill="white" opacity=".22"/>
                </svg>
            </div>
            <div class="kpi-body">
                <div class="metric-top">
                    <span class="kpi-label">Available stock units</span>
                    <span class="trend up">↗ <?= $totalItems ?> items</span>
                </div>
                <strong><?= number_format((int)$pdo->query('SELECT COALESCE(SUM(quantity),0) FROM items')->fetchColumn()) ?></strong>
                <small>Across <?= $totalItems ?> item codes</small>
            </div>
            <div class="sparkline" id="spark-0"></div>
        </article>

        <!-- Card 2: Low / reorder stock -->
        <article class="metric-card kpi-card <?= $lowStock > 0 ? 'kpi-lowstock-warn' : 'kpi-lowstock-ok' ?>" data-link="<?= page_link('inventory') ?>" style="--delay:1">
            <div class="kpi-illustration" aria-hidden="true">
                <!-- Medicine bottle with low liquid -->
                <svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <!-- Bottle body -->
                    <rect x="55" y="35" width="50" height="72" rx="12" fill="white" opacity=".2"/>
                    <rect x="55" y="35" width="50" height="72" rx="12" stroke="white" stroke-width="2.5" opacity=".4"/>
                    <!-- Bottle neck -->
                    <rect x="67" y="18" width="26" height="22" rx="5" fill="white" opacity=".25"/>
                    <rect x="67" y="18" width="26" height="22" rx="5" stroke="white" stroke-width="2" opacity=".4"/>
                    <!-- Cap -->
                    <rect x="63" y="10" width="34" height="14" rx="4" fill="white" opacity=".45"/>
                    <!-- Low level indicator -->
                    <rect x="57" y="82" width="46" height="23" rx="10" fill="white" opacity=".35"/>
                    <!-- Down arrow -->
                    <path d="M80 52 L80 72 M74 66 L80 72 L86 66" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" opacity=".6"/>
                    <!-- Warning marks -->
                    <circle cx="125" cy="30" r="14" fill="white" opacity=".2" stroke="white" stroke-width="2" opacity=".4"/>
                    <path d="M125 24 L125 32" stroke="white" stroke-width="3" stroke-linecap="round" opacity=".7"/>
                    <circle cx="125" cy="36" r="2" fill="white" opacity=".7"/>
                </svg>
            </div>
            <div class="kpi-body">
                <div class="metric-top">
                    <span class="kpi-label">Low / reorder stock</span>
                    <span class="trend <?= $lowStock > 0 ? 'down' : 'up' ?>"><?= $lowStock > 0 ? 'Needs action' : 'All OK' ?></span>
                </div>
                <strong><?= $lowStock ?></strong>
                <small><?= $criticalStock ?> items at zero stock</small>
            </div>
            <div class="sparkline" id="spark-1"></div>
        </article>

        <!-- Card 3: Near-expiry -->
        <article class="metric-card kpi-card <?= ($nearExpiry30 + $expiredItems) > 0 ? 'kpi-expiry-warn' : 'kpi-expiry-ok' ?>" data-link="<?= page_link('batches') ?>" style="--delay:2">
            <div class="kpi-illustration" aria-hidden="true">
                <!-- Capsule pill + clock/calendar -->
                <svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <!-- Large capsule -->
                    <rect x="22" y="48" width="82" height="34" rx="17" fill="white" opacity=".18" stroke="white" stroke-width="2" opacity=".35"/>
                    <!-- Capsule divider -->
                    <line x1="63" y1="48" x2="63" y2="82" stroke="white" stroke-width="2" opacity=".4"/>
                    <!-- Left half fill -->
                    <path d="M22 65 Q22 48 39 48 L63 48 L63 82 L39 82 Q22 82 22 65Z" fill="white" opacity=".3"/>
                    <!-- Small pills -->
                    <ellipse cx="130" cy="55" rx="14" ry="8" fill="white" opacity=".2" stroke="white" stroke-width="1.5" opacity=".35"/>
                    <line x1="130" y1="47" x2="130" y2="63" stroke="white" stroke-width="1.5" opacity=".35"/>
                    <ellipse cx="130" cy="80" rx="14" ry="8" fill="white" opacity=".25" stroke="white" stroke-width="1.5" opacity=".35"/>
                    <!-- Clock face -->
                    <circle cx="38" cy="25" r="16" fill="white" opacity=".18" stroke="white" stroke-width="2" opacity=".4"/>
                    <!-- Clock hands -->
                    <line x1="38" y1="25" x2="38" y2="14" stroke="white" stroke-width="2.5" stroke-linecap="round" opacity=".7"/>
                    <line x1="38" y1="25" x2="46" y2="25" stroke="white" stroke-width="2" stroke-linecap="round" opacity=".7"/>
                    <!-- Clock tick marks -->
                    <line x1="38" y1="11" x2="38" y2="14" stroke="white" stroke-width="2" opacity=".5"/>
                    <line x1="38" y1="36" x2="38" y2="39" stroke="white" stroke-width="2" opacity=".5"/>
                    <line x1="24" y1="25" x2="27" y2="25" stroke="white" stroke-width="2" opacity=".5"/>
                    <line x1="49" y1="25" x2="52" y2="25" stroke="white" stroke-width="2" opacity=".5"/>
                </svg>
            </div>
            <div class="kpi-body">
                <div class="metric-top">
                    <span class="kpi-label">Near-expiry (30 days)</span>
                    <span class="trend down"><?= $expiredItems ?> expired</span>
                </div>
                <strong><?= $nearExpiry30 ?></strong>
                <small>Review FEFO allocation</small>
            </div>
            <div class="sparkline" id="spark-2"></div>
        </article>

        <!-- Card 4: Purchase orders -->
        <article class="metric-card kpi-card kpi-purchase" data-link="<?= page_link('purchase_orders') ?>" style="--delay:3">
            <div class="kpi-illustration" aria-hidden="true">
                <!-- Clipboard with order list -->
                <svg viewBox="0 0 160 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <!-- Clipboard board -->
                    <rect x="35" y="20" width="90" height="90" rx="8" fill="white" opacity=".18" stroke="white" stroke-width="2" opacity=".35"/>
                    <!-- Clipboard top clip -->
                    <rect x="60" y="13" width="40" height="18" rx="5" fill="white" opacity=".35"/>
                    <rect x="68" y="10" width="24" height="12" rx="3" fill="white" opacity=".5"/>
                    <!-- List lines -->
                    <line x1="50" y1="48" x2="115" y2="48" stroke="white" stroke-width="2.5" stroke-linecap="round" opacity=".4"/>
                    <line x1="50" y1="62" x2="115" y2="62" stroke="white" stroke-width="2.5" stroke-linecap="round" opacity=".4"/>
                    <line x1="50" y1="76" x2="95" y2="76" stroke="white" stroke-width="2.5" stroke-linecap="round" opacity=".4"/>
                    <!-- Checkboxes -->
                    <rect x="42" y="42" width="8" height="8" rx="2" fill="white" opacity=".5"/>
                    <path d="M43.5 46 L45 47.5 L48 44" stroke="white" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" opacity=".9"/>
                    <rect x="42" y="56" width="8" height="8" rx="2" fill="white" opacity=".5"/>
                    <path d="M43.5 60 L45 61.5 L48 58" stroke="white" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" opacity=".9"/>
                    <rect x="42" y="70" width="8" height="8" rx="2" fill="white" opacity=".35"/>
                    <!-- Pen -->
                    <path d="M110 80 L125 65 L130 70 L115 85 Z" fill="white" opacity=".35"/>
                    <path d="M125 65 L129 62 L132 65 L130 70 Z" fill="white" opacity=".5"/>
                    <line x1="110" y1="80" x2="108" y2="88" stroke="white" stroke-width="1.5" stroke-linecap="round" opacity=".4"/>
                </svg>
            </div>
            <div class="kpi-body">
                <div class="metric-top">
                    <span class="kpi-label">Purchase orders</span>
                    <span class="trend neutral"><?= $openPOs ?> open</span>
                </div>
                <strong><?= $totalPOs ?></strong>
                <small><?= $pendingGRNs ?> pending GRN<?= $pendingGRNs !== 1 ? 's' : '' ?></small>
            </div>
            <div class="sparkline" id="spark-3"></div>
        </article>

    </div>

    <!-- ── KPI Row 2: Operations ─────────────────────────────────────── -->
    <div class="section-heading" style="margin-top:1.5rem">
        <div><p class="eyebrow">TODAY'S OPERATIONS</p><h2>Daily activity</h2></div>
    </div>
    <div class="metric-grid four-col">
        <article class="metric-card metric-purple" data-link="<?= page_link('opd_consumption') ?>" style="--delay:0">
            <div class="metric-top"><span class="metric-icon">✚</span></div>
            <p>OPD patients served</p>
            <strong><?= $todayOPD ?></strong>
            <small>Consumption entries today</small>
        </article>
        <article class="metric-card metric-purple" data-link="<?= page_link('ot_consumption') ?>" style="--delay:1">
            <div class="metric-top"><span class="metric-icon">⊗</span></div>
            <p>OT surgeries today</p>
            <strong><?= $todayOT ?></strong>
            <small>Consumption posted</small>
        </article>
        <article class="metric-card metric-blue" data-link="<?= page_link('requisitions') ?>" style="--delay:2">
            <div class="metric-top"><span class="metric-icon">⌁</span><span class="trend neutral"><?= $pendingReqs ?> pending</span></div>
            <p>Requisitions</p>
            <strong><?= (int)$pdo->query('SELECT COUNT(*) FROM requisitions')->fetchColumn() ?></strong>
            <small><?= $pendingReqs ?> awaiting action</small>
        </article>
        <article class="metric-card metric-blue" data-link="<?= page_link('assets') ?>" style="--delay:3">
            <div class="metric-top"><span class="metric-icon">▤</span><?php if ($stockValue > 0): ?><span class="trend up" style="font-size:9px">₨ <?= number_format($stockValue, 0) ?></span><?php endif; ?></div>
            <p>Fixed assets</p>
            <strong><?= $totalAssets ?></strong>
            <small><?= $assetWarrantyExpiring ?> warranty expiring soon</small>
        </article>
    </div>

    <!-- ── Alert panels ──────────────────────────────────────────────── -->
    <div class="dashboard-grid" style="margin-top:1.5rem">
        <!-- Low stock -->
        <section class="panel alert-panel">
            <div class="panel-heading">
                <div><p class="eyebrow">STOCK ALERTS</p><h2>Low &amp; critical stock</h2></div>
                <a class="text-button" href="<?= page_link('inventory') ?>">View all →</a>
            </div>
            <div class="alert-list">
                <?php if (empty($lowStockItems)): ?>
                <div class="alert-item"><span class="alert-symbol blue">✓</span><div><strong>All stock levels are healthy</strong></div></div>
                <?php else: foreach ($lowStockItems as $ls): ?>
                <div class="alert-item">
                    <span class="alert-symbol <?= $ls['quantity'] == 0 ? 'red' : 'amber' ?>"><?= $ls['quantity'] == 0 ? '!' : '↓' ?></span>
                    <div>
                        <strong><?= e($ls['name']) ?></strong>
                        <small><?= e($ls['code']) ?> · <?= $ls['quantity'] ?> in stock (min <?= $ls['reorder_level'] ?>)</small>
                    </div>
                    <a href="<?= page_link('inventory') ?>" class="row-action">›</a>
                </div>
                <?php endforeach; endif; ?>
            </div>
        </section>

        <!-- Near expiry -->
        <section class="panel alert-panel">
            <div class="panel-heading">
                <div><p class="eyebrow">EXPIRY ALERTS</p><h2>Expiring soon</h2></div>
                <a class="text-button" href="<?= page_link('batches') ?>">View all →</a>
            </div>
            <div class="alert-list">
                <?php if (empty($expiryItems)): ?>
                <div class="alert-item"><span class="alert-symbol blue">✓</span><div><strong>No near-expiry items</strong></div></div>
                <?php else: foreach ($expiryItems as $ei): ?>
                <div class="alert-item">
                    <span class="alert-symbol <?= $ei['days_left'] <= 30 ? 'red' : ($ei['days_left'] <= 60 ? 'amber' : 'blue') ?>"><?= $ei['days_left'] <= 0 ? '!' : '◷' ?></span>
                    <div>
                        <strong><?= e($ei['name']) ?></strong>
                        <small><?= e($ei['code']) ?> · Expires <?= e($ei['expiry_date']) ?> (<?= $ei['days_left'] ?> days)</small>
                    </div>
                </div>
                <?php endforeach; endif; ?>
            </div>
        </section>
    </div>

    <!-- ── Recent transactions ───────────────────────────────────────── -->
    <div class="dashboard-grid lower-grid" style="margin-top:1.5rem">
        <section class="panel table-panel" style="grid-column:1/-1">
            <div class="panel-heading">
                <div><p class="eyebrow">AUDIT TRAIL</p><h2>Recent activity</h2></div>
                <a class="text-button" href="<?= page_link('reports') ?>">Full history →</a>
            </div>
            <div class="table-wrap">
                <?php if (empty($recentTx)): ?>
                <div class="empty-state">
                    <span class="empty-icon">📋</span>
                    <p>No transactions recorded yet.</p>
                    <small>Activity will appear here once items are received or issued.</small>
                </div>
                <?php else: ?>
                <table>
                    <thead><tr><th>Activity</th><th>Reference</th><th>Party / Location</th><th>Qty</th><th>Status</th><th>When</th></tr></thead>
                    <tbody>
                    <?php foreach ($recentTx as $row): ?>
                    <tr>
                        <td><span class="table-icon"><?= $row['type'] === 'Patient consumption' ? '✚' : ($row['type'] === 'Goods received' ? '▣' : '↗') ?></span><?= e($row['type']) ?></td>
                        <td><b><?= e($row['reference']) ?></b></td>
                        <td><?= e($row['party']) ?></td>
                        <td><?= (int)$row['quantity'] ?></td>
                        <td><?= pill($row['status']) ?></td>
                        <td class="muted"><span class="rel-time" data-ts="<?= e($row['created_at']) ?>" title="<?= e(date('d M Y, g:i A', strtotime($row['created_at']))) ?>"><?= date('g:i A', strtotime($row['created_at'])) ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </section>
    </div>
</section>
</main>
</div>

<!-- ── Ctrl+K Spotlight ──────────────────────────────────────────────────── -->
<div class="spotlight-backdrop" id="spotlight" role="dialog" aria-modal="true" aria-label="Module search">
    <div class="spotlight-box">
        <div class="spotlight-input-wrap">
            <span class="spotlight-icon">⌕</span>
            <input type="search" id="spotlight-input" placeholder="Jump to module…" autocomplete="off" spellcheck="false">
            <kbd class="spotlight-esc">Esc</kbd>
        </div>
        <ul class="spotlight-list" id="spotlight-list"></ul>
    </div>
</div>

<script>
// ── Inject sparkline data for JS to read ────────────────────────────────────
window.SIOVS_SPARK = <?= $sparkJson ?>;
</script>
<script src="assets/app.js"></script>
</body>
</html>
