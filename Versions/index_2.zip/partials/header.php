<?php
require_login();
$current = $current ?? 'dashboard';
$title   = $title   ?? 'SIOVS';
$flash   = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
$u = current_user();
$initials = implode('', array_map(fn($w) => strtoupper($w[0]), array_slice(explode(' ', $u['name'] ?? 'U'), 0, 2)));
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> · SIOVS SIMS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="assets/system.css">
    <link rel="stylesheet" href="assets/green-theme.css">
</head>
<body>
<div class="app-shell">
<aside class="sidebar">
    <a class="brand" href="index.php">
        <img class="brand-logo" src="https://siovs.edu.pk/wp-content/uploads/2022/09/logo-main.png" alt="SIOVS logo">
        <span><strong>SIOVS</strong><small>Store Management</small></span>
    </a>
    <div class="workspace-switcher"><span class="dot"></span><span>SIOVS Hyderabad</span><span class="chevron">⌄</span></div>
    <nav>
        <p class="nav-label">Overview</p>
        <a class="nav-link <?= $current === 'dashboard' ? 'active' : '' ?>" href="index.php"><span>◈</span> Dashboard</a>
        <?php if (can('reports')): ?>
        <a class="nav-link <?= $current === 'reports' ? 'active' : '' ?>" href="<?= page_link('reports') ?>"><span>▥</span> Reports &amp; analytics</a>
        <?php endif; ?>

        <p class="nav-label">Inventory</p>
        <?php if (can('inventory')): ?>
        <a class="nav-link <?= $current === 'inventory' ? 'active' : '' ?>" href="<?= page_link('inventory') ?>"><span>◫</span> Item master / stock</a>
        <?php endif; ?>
        <?php if (can('batches')): ?>
        <a class="nav-link <?= $current === 'batches' ? 'active' : '' ?>" href="<?= page_link('batches') ?>"><span>◷</span> Batch &amp; expiry</a>
        <?php endif; ?>
        <?php if (can('adjustments')): ?>
        <a class="nav-link <?= $current === 'adjustments' ? 'active' : '' ?>" href="<?= page_link('adjustments') ?>"><span>⇌</span> Stock adjustments</a>
        <?php endif; ?>
        <?php if (can('verification')): ?>
        <a class="nav-link <?= $current === 'verification' ? 'active' : '' ?>" href="<?= page_link('verification') ?>"><span>✓</span> Stock verification</a>
        <?php endif; ?>

        <?php if (can('requisitions')): ?>
        <p class="nav-label">Requisitions &amp; Issues</p>
        <a class="nav-link <?= $current === 'requisitions' ? 'active' : '' ?>" href="<?= page_link('requisitions') ?>"><span>⌁</span> Issue requisition</a>
        <?php endif; ?>

        <?php if (can('purchase_orders') || can('suppliers') || can('grn')): ?>
        <p class="nav-label">Purchase &amp; Receiving</p>
        <?php if (can('suppliers')): ?>
        <a class="nav-link <?= $current === 'suppliers' ? 'active' : '' ?>" href="<?= page_link('suppliers') ?>"><span>⊞</span> Suppliers</a>
        <?php endif; ?>
        <?php if (can('purchase_orders')): ?>
        <a class="nav-link <?= $current === 'purchase_orders' ? 'active' : '' ?>" href="<?= page_link('purchase_orders') ?>"><span>↗</span> Purchase orders</a>
        <?php endif; ?>
        <?php if (can('grn')): ?>
        <a class="nav-link <?= $current === 'grn' ? 'active' : '' ?>" href="<?= page_link('grn') ?>"><span>▣</span> Goods received (GRN)</a>
        <?php endif; ?>
        <?php endif; ?>

        <?php if (can('opd_consumption') || can('ipd_consumption') || can('ot_consumption') || can('emergency')): ?>
        <p class="nav-label">Departments &amp; Issues</p>
        <?php if (can('opd_consumption')): ?>
        <a class="nav-link <?= $current === 'opd_consumption' ? 'active' : '' ?>" href="<?= page_link('opd_consumption') ?>"><span>✚</span> OPD consumption</a>
        <?php endif; ?>
        <?php if (can('ipd_consumption')): ?>
        <a class="nav-link <?= $current === 'ipd_consumption' ? 'active' : '' ?>" href="<?= page_link('ipd_consumption') ?>"><span>⊕</span> IPD / Ward</a>
        <?php endif; ?>
        <?php if (can('ot_consumption')): ?>
        <a class="nav-link <?= $current === 'ot_consumption' ? 'active' : '' ?>" href="<?= page_link('ot_consumption') ?>"><span>⊗</span> OT / Surgery</a>
        <?php endif; ?>
        <?php if (can('emergency')): ?>
        <a class="nav-link <?= $current === 'emergency' ? 'active' : '' ?>" href="<?= page_link('emergency') ?>"><span>!</span> Emergency</a>
        <?php endif; ?>
        <?php endif; ?>

        <?php if (can('assets') || can('departments')): ?>
        <p class="nav-label">Assets &amp; Control</p>
        <?php if (can('assets')): ?>
        <a class="nav-link <?= $current === 'assets' ? 'active' : '' ?>" href="<?= page_link('assets') ?>"><span>▤</span> Fixed assets</a>
        <?php endif; ?>
        <?php if (can('departments')): ?>
        <a class="nav-link <?= $current === 'departments' ? 'active' : '' ?>" href="<?= page_link('departments') ?>"><span>⊟</span> Departments</a>
        <?php endif; ?>
        <?php if (can('returns')): ?>
        <a class="nav-link <?= $current === 'returns' ? 'active' : '' ?>" href="<?= page_link('returns') ?>"><span>↻</span> Returns</a>
        <?php endif; ?>
        <?php if (can('users')): ?>
        <a class="nav-link <?= $current === 'users' ? 'active' : '' ?>" href="<?= page_link('users') ?>"><span>♙</span> Users &amp; roles</a>
        <?php endif; ?>
        <?php endif; ?>

        <?php if (can('quick-entry')): ?>
        <p class="nav-label">Quick Entry</p>
        <a class="nav-link <?= $current === 'quick-entry' ? 'active' : '' ?>" href="<?= page_link('quick-entry') ?>"><span>＋</span> Quick entry</a>
        <?php endif; ?>
    </nav>
    <div class="sidebar-bottom">
        <div class="user-chip">
            <span class="avatar"><?= e($initials) ?></span>
            <div><strong><?= e($u['name'] ?? '') ?></strong><small><?= e(role_label($u['role'] ?? '')) ?></small></div>
            <a class="logout" href="logout.php" title="Sign out">↪</a>
        </div>
    </div>
</aside>
<main class="main">
<header class="topbar">
    <div class="breadcrumbs"><span>Workspace</span><b>/</b><strong><?= e($title) ?></strong></div>
    <div class="top-actions">
        <button class="icon-button" title="Alerts">♢<i>7</i></button>
        <?php if (can('quick-entry')): ?>
        <a class="button button-primary" href="<?= page_link('quick-entry') ?>">＋ Quick entry</a>
        <?php endif; ?>
    </div>
</header>
<?php if ($flash): ?>
<div class="flash <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>
